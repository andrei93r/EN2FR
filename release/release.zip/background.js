// src/background.ts
console.log("Starting DeepL Script");
chrome.runtime.onMessage.addListener((message) => {
  if (message.actionType === "WindowControl") {
    chrome.windows.create({
      url: message.payLoad.url,
      type: message.payLoad.openStyle,
      width: message.payLoad.openStyle == "popup" ? 1145 : 1920,
      height: 1080
    });
  }
});
//# sourceMappingURL=background.js.map
