// src/deepMod.ts
console.log("Started deepMod.js");
var observer = new MutationObserver(() => {
  const clipButton = document.querySelector('[aria-label="Copy to clipboard"]');
  if (clipButton) {
    clipButton.addEventListener("click", () => {
      setTimeout(() => {
        window.close();
      }, 200);
    });
  }
});
observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeOldValue: true });
//# sourceMappingURL=deepMod.js.map
