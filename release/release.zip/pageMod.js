// src/pageMod.ts
console.log("Any Page Started");
var pressedKeys = /* @__PURE__ */ new Set();
document.addEventListener("keydown", (event) => {
  const key = event.key.toLowerCase();
  console.log("Key", key);
  console.log(pressedKeys);
  switch (key) {
    case "alt":
      pressedKeys.add(key);
      break;
    case "t":
      if (pressedKeys.has("alt")) {
        let getHighlightedText2 = function() {
          return window.getSelection()?.toString();
        };
        var getHighlightedText = getHighlightedText2;
        console.log("Alt + t pressed!");
        const defaultUrl = "https://www.deepl.com/en/translator#en/fr/";
        const param = getHighlightedText2();
        if (!param) return OpenPopUp(defaultUrl);
        OpenPopUp(`${defaultUrl}${encodeURIComponent(param)}`);
      }
      pressedKeys.clear();
      break;
    case "q":
      window.close();
      break;
    default:
      pressedKeys.clear();
  }
});
function OpenPopUp(url) {
  const message = {
    actionType: "WindowControl",
    payLoad: {
      openStyle: "popup",
      url
    }
  };
  chrome.runtime.sendMessage(message);
}
//# sourceMappingURL=pageMod.js.map
